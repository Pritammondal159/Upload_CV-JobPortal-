<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DependentDropdownController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $states = State::all();
        return view('demo.dependent_dropdown.index',compact('states'));
    }
    public function destroy($id)
    {
        //
    }
    public function findCityWithStateID($id)
    {
        $city = City::where('state_id',$id)->get();
        return response()->json($city);
    }
}
