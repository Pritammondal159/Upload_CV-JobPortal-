@extends('layouts.app')

@section('title')
Online CV Upload and Download Management System
@endsection

@section('content')
     <div class="jumbotron">
        <div class="mx-auto align-middle jumbotron-content">
            <div>
              <h1 class="display-4 h1">Find The Job and Download Management System</h1>
              <form action="/userdashboard" method="get">
                <div class="input-group mb-3 w-50">
                  <input type="text" class="form-control" placeholder="Search Jobs" aria-label="Amount (rounded to the nearest dollar)" aria-describedby="basic-addon" name="search">
                  <div class="input-group-append">
                    <button class="input-group-text bg-info text-light" id="basic-addon" type="submit"><i class="fas fa-search"></i></button>
                  </div>
                </div>
              </form>  
          </div>
       </div>
    </div>
@endsection