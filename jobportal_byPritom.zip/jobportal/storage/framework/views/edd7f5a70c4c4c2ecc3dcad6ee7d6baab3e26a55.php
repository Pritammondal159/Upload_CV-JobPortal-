<footer>
	
</footer><?php /**PATH E:\xampp\htdocs\jobportal\resources\views/partials/footer.blade.php ENDPATH**/ ?>