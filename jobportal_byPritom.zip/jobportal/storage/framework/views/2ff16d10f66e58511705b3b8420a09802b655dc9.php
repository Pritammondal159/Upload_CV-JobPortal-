 <nav class="navbar navbar-expand-sm navbar-light navbar-laravel">
       
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <?php if(auth()->guard()->guest()): ?>
            <!-- Left Side Of Navbar -->
              <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="/userdashboard">FIND WORK<span class="sr-only">(current)</span></a>
                </li>
              </ul>
            <?php else: ?>
            <?php if(Auth::user()->role == 1): ?>
                <!-- Left Side Of Navbar -->
                  <ul class="navbar-nav mr-auto">
                     <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="/userdashboard">FIND WORK<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="/profile/<?php echo e(str_slug(strtolower(Auth::user()->name), '-')); ?>">PROFILE</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="/my-jobs">MY JOBS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="">MESSAGES</a>
                    </li>
                  </ul>                      
             <?php endif; ?>  

             <?php if(Auth::user()->role == 2): ?>
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="/jobs">JOBS<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="/dashboard">DASHBOARD</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="">MESSAGES</a>
                    </li> 
                 </ul>                      
             <?php endif; ?>     
             <?php if(Auth::user()->role == 3): ?>    
                 <ul class="navbar-nav mr-auto">
                     <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="/panel/freelancer">FREELANCERS<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="/panel/clients">CLIENTS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="/panel/jobs">JOBS</a>
                    </li>
                  </ul>                     
              <?php endif; ?>  
            <?php endif; ?>      
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto list-group">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <li><a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="<?php echo e(route('login')); ?>">LOGIN</a></li>
                    <li><a class="nav-link list-group-item list-group-item-action flex-column align-items-end" href="<?php echo e(route('register')); ?>">SIGN UP</a></li>
                    <li><a class="nav-link" href=""><button class="btn btn-sm align-middle btn-info" type="button">POST A JOB</button></a></li>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?php if(Auth::user()->role == 1): ?>
                                <a href="/dashboard" class="dropdown-item" >Account Settings</a>
                            <?php endif; ?>  
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                Logout
                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
</nav><?php /**PATH E:\xampp\htdocs\jobportal\resources\views/partials/navbar.blade.php ENDPATH**/ ?>