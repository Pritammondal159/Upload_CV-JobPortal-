<footer>

</footer><?php /**PATH E:\xampp\htdocs\jobportal\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>